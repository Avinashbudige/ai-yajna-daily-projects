#import libraries 
from fastapi import FastAPI, UploadFile, File
from collections import defaultdict 
 
app = FastAPI() #initializing the application 

@app.get("/")
def welcome():
    return "API is working"

@app.post("/analyze-log/")
async def analyze_file(file: UploadFile = File(...)):
    contents = await file.read()  # This gives you all file content (still in memory)
    lines = contents.decode("utf-8").splitlines()  # Split into lines

    counts = defaultdict(int)
    
    for line in lines:
        line_text = line
        
        if "INFO" in line_text:
            counts["INFO"] += 1
        if "WARNING" in line_text:
            counts["WARNING"] += 1
        if "ERROR" in line_text:
            counts["ERROR"] += 1
    
    return counts
